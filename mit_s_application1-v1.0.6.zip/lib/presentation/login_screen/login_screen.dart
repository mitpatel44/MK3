import 'package:flutter/material.dart';
import 'package:mit_s_application1/core/app_export.dart';
import 'package:mit_s_application1/widgets/custom_elevated_button.dart';
import 'package:mit_s_application1/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);

  TextEditingController userNameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: Container(
                    width: double.maxFinite,
                    padding:
                        EdgeInsets.symmetric(horizontal: 37.h, vertical: 38.v),
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                              padding: EdgeInsets.only(left: 3.h, top: 47.v),
                              child: Text("Login Now",
                                  style: theme.textTheme.headlineLarge)),
                          Container(
                              width: 243.h,
                              margin: EdgeInsets.only(left: 3.h, right: 73.h),
                              child: Text(
                                  "Please login or sign up to continue using\nour app",
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: CustomTextStyles
                                      .labelLargeMplus1pBoldBold)),
                          SizedBox(height: 21.v),
                          CustomImageView(
                              imagePath: ImageConstant.imgImage14,
                              height: 201.v,
                              width: 251.h,
                              alignment: Alignment.center),
                          CustomTextFormField(
                              controller: userNameController,
                              margin: EdgeInsets.only(top: 24.v, right: 11.h),
                              hintText: "Username"),
                          CustomTextFormField(
                              controller: passwordController,
                              margin: EdgeInsets.only(top: 22.v, right: 11.h),
                              hintText: "Password",
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.visiblePassword,
                              suffix: Container(
                                  margin: EdgeInsets.fromLTRB(
                                      30.h, 15.v, 12.h, 14.v),
                                  child: CustomImageView(
                                      svgPath: ImageConstant.imgMdieye)),
                              suffixConstraints:
                                  BoxConstraints(maxHeight: 53.v),
                              obscureText: true,
                              contentPadding: EdgeInsets.only(
                                  left: 30.h, top: 11.v, bottom: 11.v)),
                          Align(
                              alignment: Alignment.centerRight,
                              child: Padding(
                                  padding:
                                      EdgeInsets.only(top: 21.v, right: 15.h),
                                  child: Text("Forgot Password?",
                                      style: CustomTextStyles
                                          .labelLargeMplus1pBold))),
                          CustomElevatedButton(
                              text: "Sign up",
                              margin: EdgeInsets.only(
                                  left: 3.h, top: 52.v, right: 6.h),
                              onTap: () {
                                onTapSignup(context);
                              }),
                          Align(
                              alignment: Alignment.center,
                              child: Padding(
                                  padding: EdgeInsets.only(
                                      left: 37.h, top: 20.v, right: 23.h),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                            padding:
                                                EdgeInsets.only(bottom: 7.v),
                                            child: Text(
                                                "Don’t have an account?  ",
                                                style: CustomTextStyles
                                                    .labelLargeMplus1pBold)),
                                        CustomElevatedButton(
                                            height: 27.v,
                                            width: 100.h,
                                            text: "Sign up",
                                            margin: EdgeInsets.only(left: 7.h),
                                            buttonStyle:
                                                CustomButtonStyles.fillBlueGray,
                                            buttonTextStyle: CustomTextStyles
                                                .labelLargeMplus1pBoldPrimary,
                                            onTap: () {
                                              onTapSignup1(context);
                                            })
                                      ])))
                        ])))));
  }

  /// Navigates to the homeContainerScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the homeContainerScreen.
  onTapSignup(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homeContainerScreen);
  }

  /// Navigates to the signUpScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the signUpScreen.
  onTapSignup1(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signUpScreen);
  }
}
