import 'package:flutter/material.dart';
import 'package:mit_s_application1/core/app_export.dart';
import 'package:mit_s_application1/presentation/categories_page/categories_page.dart';
import 'package:mit_s_application1/presentation/favorites_page/favorites_page.dart';
import 'package:mit_s_application1/presentation/home_page/home_page.dart';
import 'package:mit_s_application1/presentation/my_bag_page/my_bag_page.dart';
import 'package:mit_s_application1/presentation/my_profile_page/my_profile_page.dart';
import 'package:mit_s_application1/widgets/app_bar/appbar_image_2.dart';
import 'package:mit_s_application1/widgets/app_bar/appbar_image_3.dart';
import 'package:mit_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:mit_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:mit_s_application1/widgets/custom_bottom_bar.dart';
import 'package:mit_s_application1/widgets/custom_elevated_button.dart';

class CheckoutScreen extends StatelessWidget {
  CheckoutScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        appBar: CustomAppBar(
          centerTitle: true,
          title: Column(
            children: [
              Padding(
                padding: EdgeInsets.only(
                  left: 22.h,
                  right: 30.h,
                ),
                child: Row(
                  children: [
                    Container(
                      margin: EdgeInsets.only(
                        top: 7.v,
                        bottom: 10.v,
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: 7.h,
                        vertical: 14.v,
                      ),
                      decoration: AppDecoration.fillBlueGray,
                      child: Column(
                        children: [
                          SizedBox(height: 3.v),
                          AppbarImage2(
                            svgPath: ImageConstant.imgArrow2,
                          ),
                        ],
                      ),
                    ),
                    AppbarTitle(
                      text: "Checkout",
                      margin: EdgeInsets.only(
                        left: 58.h,
                        bottom: 6.v,
                      ),
                    ),
                    AppbarImage3(
                      svgPath: ImageConstant.imgSearch,
                      margin: EdgeInsets.only(
                        left: 62.h,
                        top: 10.v,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 8.v),
              SizedBox(
                width: double.maxFinite,
                child: Divider(),
              ),
            ],
          ),
          styleType: Style.bgFill,
        ),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 15.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: 16.h,
                      right: 21.h,
                      bottom: 5.v,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 158.v,
                          width: 356.h,
                          child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                  height: 147.v,
                                  width: 356.h,
                                  decoration: BoxDecoration(
                                    color: appTheme.blueGray100,
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 18.h,
                                    vertical: 9.v,
                                  ),
                                  decoration: AppDecoration.fillOnPrimary,
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(left: 4.h),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Padding(
                                              padding:
                                                  EdgeInsets.only(top: 2.v),
                                              child: Text(
                                                "Axit Patel",
                                                style:
                                                    theme.textTheme.titleMedium,
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                                  EdgeInsets.only(bottom: 2.v),
                                              child: Text(
                                                "Change",
                                                style: CustomTextStyles
                                                    .titleMediumPrimary,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(left: 4.h),
                                        child: Text(
                                          "0987654321",
                                          style: theme.textTheme.titleMedium,
                                        ),
                                      ),
                                      Container(
                                        height: 47.v,
                                        width: 233.h,
                                        margin: EdgeInsets.only(
                                          left: 3.h,
                                          top: 1.v,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.bottomCenter,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Padding(
                                                padding:
                                                    EdgeInsets.only(left: 1.h),
                                                child: Text(
                                                  "4517 Washington Ave.",
                                                  style: theme
                                                      .textTheme.titleMedium,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.bottomCenter,
                                              child: Text(
                                                "Manchester, Kentucky 39495",
                                                style:
                                                    theme.textTheme.titleMedium,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Shipping address",
                                  style: theme.textTheme.titleMedium,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 31.v),
                        Text(
                          "Delivery method",
                          style: CustomTextStyles
                              .titleMediumMetropolisOnPrimaryContainer,
                        ),
                        SizedBox(height: 24.v),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.only(right: 11.h),
                                padding: EdgeInsets.symmetric(
                                  horizontal: 19.h,
                                  vertical: 17.v,
                                ),
                                decoration:
                                    AppDecoration.outlineBlack9002.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder6,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    CustomImageView(
                                      svgPath: ImageConstant.imgLayer1,
                                      height: 19.v,
                                      width: 63.h,
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                        top: 13.v,
                                        right: 6.h,
                                      ),
                                      child: Text(
                                        " 2-3 days",
                                        style: CustomTextStyles.bodySmall11,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.symmetric(horizontal: 11.h),
                                padding: EdgeInsets.symmetric(
                                  horizontal: 9.h,
                                  vertical: 17.v,
                                ),
                                decoration:
                                    AppDecoration.outlineBlack9002.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder6,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    SizedBox(height: 9.v),
                                    CustomImageView(
                                      svgPath: ImageConstant.imgCar,
                                      height: 11.v,
                                      width: 85.h,
                                    ),
                                    SizedBox(height: 13.v),
                                    Text(
                                      " 2-3 days",
                                      style: CustomTextStyles.bodySmall11,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.only(left: 11.h),
                                padding: EdgeInsets.symmetric(
                                  horizontal: 14.h,
                                  vertical: 17.v,
                                ),
                                decoration:
                                    AppDecoration.outlineBlack9002.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder6,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(height: 2.v),
                                    CustomImageView(
                                      svgPath: ImageConstant.imgMenu,
                                      height: 17.v,
                                      width: 73.h,
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                        top: 13.v,
                                        right: 11.h,
                                      ),
                                      child: Text(
                                        " 2-3 days",
                                        style: CustomTextStyles.bodySmall11,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 6.h,
                            top: 25.v,
                          ),
                          child: RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "Payment : ",
                                  style: theme.textTheme.titleMedium,
                                ),
                                TextSpan(
                                  text: "Only cash on delivery available  ",
                                  style: theme.textTheme.titleMedium,
                                ),
                              ],
                            ),
                            textAlign: TextAlign.left,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 9.h,
                            top: 33.v,
                          ),
                          child: Text(
                            "Order :                                      Rs. 2,050",
                            style: CustomTextStyles.titleMediumPrimary,
                          ),
                        ),
                        Container(
                          height: 24.v,
                          width: 292.h,
                          margin: EdgeInsets.only(
                            left: 11.h,
                            top: 6.v,
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Align(
                                alignment: Alignment.center,
                                child: Text(
                                  "Delivery :                                  Rs. 50",
                                  style: CustomTextStyles.titleMediumPrimary,
                                ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Text(
                                  "Delivery :                                  Rs. 50",
                                  style: CustomTextStyles.titleMediumPrimary,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 11.h,
                            top: 6.v,
                          ),
                          child: Text(
                            "Summary :                                 Rs. 2,100",
                            style: CustomTextStyles.titleMediumPrimary,
                          ),
                        ),
                        CustomElevatedButton(
                          height: 48.v,
                          text: "SUBMIT ORDER",
                          margin: EdgeInsets.only(
                            left: 4.h,
                            top: 22.v,
                            right: 9.h,
                          ),
                          buttonStyle: CustomButtonStyles.outlineErrorContainer,
                          buttonTextStyle: theme.textTheme.titleSmall!,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homePage;
      case BottomBarEnum.Shop:
        return AppRoutes.categoriesPage;
      case BottomBarEnum.Bag:
        return AppRoutes.myBagPage;
      case BottomBarEnum.Favorites:
        return AppRoutes.favoritesPage;
      case BottomBarEnum.Profile:
        return AppRoutes.myProfilePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage();
      case AppRoutes.categoriesPage:
        return CategoriesPage();
      case AppRoutes.myBagPage:
        return MyBagPage();
      case AppRoutes.favoritesPage:
        return FavoritesPage();
      case AppRoutes.myProfilePage:
        return MyProfilePage();
      default:
        return DefaultWidget();
    }
  }
}
