import '../blender_screen/widgets/productcard_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:mit_s_application1/core/app_export.dart';
import 'package:mit_s_application1/presentation/categories_page/categories_page.dart';
import 'package:mit_s_application1/presentation/favorites_page/favorites_page.dart';
import 'package:mit_s_application1/presentation/home_page/home_page.dart';
import 'package:mit_s_application1/presentation/my_bag_page/my_bag_page.dart';
import 'package:mit_s_application1/presentation/my_profile_page/my_profile_page.dart';
import 'package:mit_s_application1/widgets/app_bar/appbar_image_2.dart';
import 'package:mit_s_application1/widgets/app_bar/appbar_image_3.dart';
import 'package:mit_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:mit_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:mit_s_application1/widgets/custom_bottom_bar.dart';

class BlenderScreen extends StatelessWidget {
  BlenderScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        appBar: CustomAppBar(
          centerTitle: true,
          title: Column(
            children: [
              Padding(
                padding: EdgeInsets.only(
                  left: 22.h,
                  right: 30.h,
                ),
                child: Row(
                  children: [
                    Container(
                      margin: EdgeInsets.only(
                        top: 7.v,
                        bottom: 10.v,
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: 7.h,
                        vertical: 14.v,
                      ),
                      decoration: AppDecoration.fillBlueGray,
                      child: Column(
                        children: [
                          SizedBox(height: 3.v),
                          AppbarImage2(
                            svgPath: ImageConstant.imgArrow2,
                          ),
                        ],
                      ),
                    ),
                    AppbarTitle(
                      text: "Blender",
                      margin: EdgeInsets.only(
                        left: 71.h,
                        bottom: 6.v,
                      ),
                    ),
                    AppbarImage3(
                      svgPath: ImageConstant.imgSearch,
                      margin: EdgeInsets.only(
                        left: 76.h,
                        top: 10.v,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 8.v),
              SizedBox(
                width: double.maxFinite,
                child: Divider(),
              ),
            ],
          ),
          styleType: Style.bgFill,
        ),
        body: Padding(
          padding: EdgeInsets.only(
            left: 17.h,
            top: 17.v,
            right: 23.h,
          ),
          child: ListView.separated(
            physics: BouncingScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (
              context,
              index,
            ) {
              return SizedBox(
                height: 19.v,
              );
            },
            itemCount: 3,
            itemBuilder: (context, index) {
              return ProductcardItemWidget();
            },
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homePage;
      case BottomBarEnum.Shop:
        return AppRoutes.categoriesPage;
      case BottomBarEnum.Bag:
        return AppRoutes.myBagPage;
      case BottomBarEnum.Favorites:
        return AppRoutes.favoritesPage;
      case BottomBarEnum.Profile:
        return AppRoutes.myProfilePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage();
      case AppRoutes.categoriesPage:
        return CategoriesPage();
      case AppRoutes.myBagPage:
        return MyBagPage();
      case AppRoutes.favoritesPage:
        return FavoritesPage();
      case AppRoutes.myProfilePage:
        return MyProfilePage();
      default:
        return DefaultWidget();
    }
  }
}
