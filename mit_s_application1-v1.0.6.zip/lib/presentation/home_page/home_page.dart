import 'package:flutter/material.dart';
import 'package:mit_s_application1/core/app_export.dart';
import 'package:mit_s_application1/widgets/custom_elevated_button.dart';
import 'package:mit_s_application1/widgets/custom_search_view.dart';

// ignore_for_file: must_be_immutable
class HomePage extends StatelessWidget {
  HomePage({Key? key}) : super(key: key);

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Container(
                width: double.maxFinite,
                decoration: AppDecoration.outlineBlack900,
                child: SingleChildScrollView(
                    child: Padding(
                        padding: EdgeInsets.only(bottom: 5.v),
                        child: Column(children: [
                          Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 33.h, vertical: 12.v),
                              decoration: AppDecoration.fillGray,
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    SizedBox(height: 94.v),
                                    CustomSearchView(
                                        controller: searchController,
                                        hintText: "Search",
                                        prefix: Container(
                                            margin: EdgeInsets.only(
                                                left: 12.h,
                                                top: 12.v,
                                                right: 5.h),
                                            child: CustomImageView(
                                                svgPath:
                                                    ImageConstant.imgSearch)),
                                        prefixConstraints:
                                            BoxConstraints(maxHeight: 53.v),
                                        suffix: Padding(
                                            padding:
                                                EdgeInsets.only(right: 15.h),
                                            child: IconButton(
                                                onPressed: () {
                                                  searchController.clear();
                                                },
                                                icon: Icon(Icons.clear,
                                                    color:
                                                        Colors.grey.shade600))))
                                  ])),
                          Container(
                              margin: EdgeInsets.only(
                                  left: 25.h, top: 23.v, right: 25.h),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 73.h, vertical: 16.v),
                              decoration: AppDecoration.outlineBlack9001
                                  .copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder6),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    SizedBox(height: 8.v),
                                    Text("SUMMER SALES",
                                        style: CustomTextStyles
                                            .headlineSmallMontserratOnPrimary),
                                    SizedBox(height: 9.v),
                                    Text("Up to 50% off",
                                        style: theme.textTheme.bodyMedium)
                                  ])),
                          Padding(
                              padding: EdgeInsets.only(
                                  left: 19.h, top: 41.v, right: 24.h),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Column(children: [
                                      CustomImageView(
                                          imagePath:
                                              ImageConstant.imgRectangle13,
                                          height: 149.v,
                                          width: 151.h,
                                          radius: BorderRadius.circular(74.h)),
                                      SizedBox(height: 6.v),
                                      CustomElevatedButton(
                                          width: 125.h,
                                          text: "Blender",
                                          buttonStyle:
                                              CustomButtonStyles.fillOnPrimary,
                                          buttonTextStyle:
                                              theme.textTheme.headlineSmall!,
                                          onTap: () {
                                            onTapBlender(context);
                                          }),
                                      SizedBox(height: 32.v),
                                      SizedBox(
                                          height: 207.v,
                                          width: 152.h,
                                          child: Stack(
                                              alignment: Alignment.topCenter,
                                              children: [
                                                Align(
                                                    alignment:
                                                        Alignment.bottomCenter,
                                                    child: Container(
                                                        height: 58.v,
                                                        width: 125.h,
                                                        decoration: BoxDecoration(
                                                            color: theme
                                                                .colorScheme
                                                                .onPrimary,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(10
                                                                        .h)))),
                                                CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgImage25,
                                                    height: 149.v,
                                                    width: 152.h,
                                                    radius:
                                                        BorderRadius.circular(
                                                            74.h),
                                                    alignment:
                                                        Alignment.topCenter),
                                                Align(
                                                    alignment:
                                                        Alignment.bottomRight,
                                                    child: Container(
                                                        width: 103.h,
                                                        margin: EdgeInsets.only(
                                                            right: 18.h),
                                                        child: Text(
                                                            "Chopper Grinder",
                                                            maxLines: 2,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: theme
                                                                .textTheme
                                                                .headlineSmall)))
                                              ]))
                                    ]),
                                    Container(
                                        height: 207.v,
                                        width: 151.h,
                                        margin: EdgeInsets.only(
                                            top: 3.v, bottom: 242.v),
                                        child: Stack(
                                            alignment: Alignment.topCenter,
                                            children: [
                                              Align(
                                                  alignment: Alignment
                                                      .bottomCenter,
                                                  child: Container(
                                                      height: 58.v,
                                                      width: 125.h,
                                                      decoration: BoxDecoration(
                                                          color: theme
                                                              .colorScheme
                                                              .onPrimary,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      10.h)))),
                                              CustomImageView(
                                                  imagePath: ImageConstant
                                                      .imgImage25149x151,
                                                  height: 149.v,
                                                  width: 151.h,
                                                  radius: BorderRadius.circular(
                                                      74.h),
                                                  alignment:
                                                      Alignment.topCenter),
                                              Align(
                                                  alignment:
                                                      Alignment.bottomRight,
                                                  child: Container(
                                                      width: 90.h,
                                                      margin: EdgeInsets.only(
                                                          right: 24.h),
                                                      child: Text(
                                                          "Mixer Grinder",
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: theme.textTheme
                                                              .headlineSmall)))
                                            ]))
                                  ]))
                        ]))))));
  }

  /// Navigates to the blenderScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the blenderScreen.
  onTapBlender(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.blenderScreen);
  }
}
