import '../categories_page/widgets/listblendertext_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:mit_s_application1/core/app_export.dart';
import 'package:mit_s_application1/widgets/app_bar/appbar_image.dart';
import 'package:mit_s_application1/widgets/app_bar/appbar_image_1.dart';
import 'package:mit_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:mit_s_application1/widgets/app_bar/custom_app_bar.dart';

// ignore_for_file: must_be_immutable
class CategoriesPage extends StatelessWidget {
  const CategoriesPage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        appBar: CustomAppBar(
          height: 72.v,
          leadingWidth: 58.h,
          leading: AppbarImage(
            svgPath: ImageConstant.imgArrow2,
            margin: EdgeInsets.only(
              left: 29.h,
              top: 24.v,
              bottom: 28.v,
            ),
          ),
          centerTitle: true,
          title: AppbarTitle(
            text: "Categories",
          ),
          actions: [
            AppbarImage1(
              svgPath: ImageConstant.imgSearch,
              margin: EdgeInsets.fromLTRB(30.h, 10.v, 30.h, 4.v),
            ),
          ],
        ),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 4.v),
          child: Column(
            children: [
              Divider(),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(
                    left: 18.h,
                    top: 9.v,
                    right: 18.h,
                  ),
                  child: ListView.separated(
                    physics: BouncingScrollPhysics(),
                    shrinkWrap: true,
                    separatorBuilder: (
                      context,
                      index,
                    ) {
                      return SizedBox(
                        height: 25.v,
                      );
                    },
                    itemCount: 3,
                    itemBuilder: (context, index) {
                      return ListblendertextItemWidget();
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
