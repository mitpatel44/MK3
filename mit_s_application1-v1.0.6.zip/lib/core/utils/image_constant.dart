class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Welcome  images
  static String imgWhatsappimage20230909 =
      '$imagePath/img_whatsappimage20230909.png';

  static String imgCheckmark = '$imagePath/img_checkmark.svg';

  static String imgImage3 = '$imagePath/img_image3.png';

  static String imgImage1 = '$imagePath/img_image1.png';

  static String imgImage5 = '$imagePath/img_image5.png';

  static String imgImage2 = '$imagePath/img_image2.png';

  static String imgImage4 = '$imagePath/img_image4.png';

  static String imgFrame4 = '$imagePath/img_frame4.svg';

  static String imgNotification = '$imagePath/img_notification.svg';

  static String imgVector6 = '$imagePath/img_vector6.svg';

  static String imgVector8 = '$imagePath/img_vector8.svg';

  static String imgVector9 = '$imagePath/img_vector9.svg';

  static String imgVector10 = '$imagePath/img_vector10.svg';

  static String imgLine4 = '$imagePath/img_line4.png';

  static String imgVector1 = '$imagePath/img_vector1.png';

  static String imgGroup20 = '$imagePath/img_group20.svg';

  static String imgImage8 = '$imagePath/img_image8.png';

  static String imgFrame11 = '$imagePath/img_frame11.svg';

  static String imgVector2 = '$imagePath/img_vector2.png';

  static String imgImage6 = '$imagePath/img_image6.png';

  static String imgImage7 = '$imagePath/img_image7.png';

  static String imgImage10 = '$imagePath/img_image10.png';

  static String imgImage11 = '$imagePath/img_image11.png';

  static String imgImage13 = '$imagePath/img_image13.png';

  static String imgImage9 = '$imagePath/img_image9.png';

  static String imgForward = '$imagePath/img_forward.svg';

  static String imgWoman = '$imagePath/img_woman.png';

  // login images
  static String imgImage14 = '$imagePath/img_image14.png';

  // Sign Up images
  static String imgImage15 = '$imagePath/img_image15.png';

  // Categories images
  static String imgImage23 = '$imagePath/img_image23.png';

  static String imgImage24 = '$imagePath/img_image24.png';

  // Blender images
  static String imgIcon = '$imagePath/img_icon.svg';

  static String imgRectangle12 = '$imagePath/img_rectangle12.png';

  // My Bag images
  static String imgTrash = '$imagePath/img_trash.svg';

  static String imgImage21 = '$imagePath/img_image21.png';

  static String imgNavbagOnerrorcontainer =
      '$imagePath/img_navbag_onerrorcontainer.svg';

  // Checkout images
  static String imgLayer1 = '$imagePath/img_layer1.svg';

  static String imgCar = '$imagePath/img_car.svg';

  static String imgMenu = '$imagePath/img_menu.svg';

  // Favorites images
  static String imgNavfavoritesGray900 =
      '$imagePath/img_navfavorites_gray_900.svg';

  // My Profile images
  static String imgSearchPrimary30x30 =
      '$imagePath/img_search_primary_30x30.svg';

  static String imgImage26 = '$imagePath/img_image26.png';

  static String imgArrowright = '$imagePath/img_arrowright.svg';

  static String imgNavprofileGray900 = '$imagePath/img_navprofile_gray_900.svg';

  // Common images
  static String imgMdieye = '$imagePath/img_mdieye.svg';

  static String imgSearch = '$imagePath/img_search.svg';

  static String imgRectangle13 = '$imagePath/img_rectangle13.png';

  static String imgImage25 = '$imagePath/img_image25.png';

  static String imgImage25149x151 = '$imagePath/img_image25_149x151.png';

  static String imgNavhomeOnerrorcontainer =
      '$imagePath/img_navhome_onerrorcontainer.svg';

  static String imgNavshop = '$imagePath/img_navshop.svg';

  static String imgNavbag = '$imagePath/img_navbag.svg';

  static String imgNavfavorites = '$imagePath/img_navfavorites.svg';

  static String imgNavprofile = '$imagePath/img_navprofile.svg';

  static String imgArrow2 = '$imagePath/img_arrow2.svg';

  static String imgNavhome = '$imagePath/img_navhome.svg';

  static String imgNavshopOnerrorcontainer =
      '$imagePath/img_navshop_onerrorcontainer.svg';

  static String imgImage18 = '$imagePath/img_image18.png';

  static String imgSearchPrimary = '$imagePath/img_search_primary.svg';

  static String imgIconRed700 = '$imagePath/img_icon_red_700.svg';

  static String imgRectangle10 = '$imagePath/img_rectangle10.png';

  static String imgNavshopGray500 = '$imagePath/img_navshop_gray_500.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
