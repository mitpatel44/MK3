// ignore_for_file: must_be_immutable

import 'package:axit_s_application1/core/app_export.dart';
import 'package:axit_s_application1/widgets/custom_elevated_button.dart';
import 'package:axit_s_application1/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class SignUpScreen extends StatelessWidget {
  SignUpScreen({Key? key}) : super(key: key);

  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(horizontal: 40.h, vertical: 45.v),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 40.v),
                Text("Sign Up", style: theme.textTheme.headlineLarge),
                Container(
                  width: 243.h,
                  margin: EdgeInsets.only(right: 70.h),
                  child: Text(
                    "Please login or sign up to continue using\nour app",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: CustomTextStyles.labelLargeMplus1pBoldBold,
                  ),
                ),
                SizedBox(height: 6.v),
                CustomImageView(
                  imagePath: ImageConstant.imgImage15,
                  height: 164.v,
                  width: 251.h,
                  alignment: Alignment.center,
                ),
                CustomTextFormField(
                  controller: firstNameController,
                  margin: EdgeInsets.only(left: 2.h, top: 11.v),
                  hintText: "First Name",
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'First Name is required';
                    }
                    return null;
                  },
                ),
                CustomTextFormField(
                  controller: lastNameController,
                  margin: EdgeInsets.only(left: 2.h, top: 18.v),
                  hintText: "Last Name",
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Last Name is required';
                    }
                    return null;
                  },
                ),
                CustomTextFormField(
                  controller: emailController,
                  margin: EdgeInsets.only(left: 2.h, top: 18.v),
                  hintText: "Email",
                  textInputType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Email is required';
                    } else {
                      return 'Please enter a valid email address';
                    }
                  },
                ),
                CustomTextFormField(
                  controller: passwordController,
                  margin: EdgeInsets.only(left: 2.h, top: 18.v),
                  hintText: "Password",
                  textInputAction: TextInputAction.done,
                  textInputType: TextInputType.visiblePassword,
                  suffix: Container(
                    margin: EdgeInsets.fromLTRB(30.h, 15.v, 12.h, 14.v),
                    child: CustomImageView(svgPath: ImageConstant.imgMdieye),
                  ),
                  suffixConstraints: BoxConstraints(maxHeight: 53.v),
                  obscureText: true,
                  contentPadding: EdgeInsets.only(
                    left: 30.h,
                    top: 11.v,
                    bottom: 11.v,
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Password is required';
                    }
                    return null;
                  },
                ),
                CustomElevatedButton(
                  text: "Sign up",
                  margin: EdgeInsets.only(left: 2.h, top: 21.v),
                  onTap: () {
                    if (_formKey.currentState!.validate()) {
                      // All fields are valid, you can proceed.
                      print('All fields are valid. Submitting...');
                    }
                  },
                ),
                Align(
                  alignment: Alignment.center,
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: 22.h,
                      top: 18.v,
                      right: 22.h,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: () {
                            onTapTxtConfirmation(context);
                          },
                          child: Padding(
                            padding: EdgeInsets.only(bottom: 2.v),
                            child: Text(
                              "You already have an account?  ",
                              style: CustomTextStyles.labelLargeMplus1pBold,
                            ),
                          ),
                        ),
                        CustomElevatedButton(
                          height: 23.v,
                          width: 66.h,
                          text: "Login",
                          margin: EdgeInsets.only(left: 10.h),
                          buttonStyle: CustomButtonStyles.fillBlueGray,
                          buttonTextStyle:
                              CustomTextStyles.labelLargeMplus1pBoldPrimary,
                          onTap: () {
                            onTapLogin(context);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void onTapTxtConfirmation(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginScreen);
  }

  void onTapLogin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginScreen);
  }
}
