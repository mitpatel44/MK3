import 'package:axit_s_application1/core/app_export.dart';
import 'package:axit_s_application1/widgets/app_bar/appbar_image_2.dart';
import 'package:axit_s_application1/widgets/app_bar/appbar_image_3.dart';
import 'package:axit_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:axit_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:axit_s_application1/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            appBar: CustomAppBar(
                centerTitle: true,
                title: Column(children: [
                  Padding(
                      padding: EdgeInsets.only(left: 22.h, right: 37.h),
                      child: Row(children: [
                        Container(
                            margin: EdgeInsets.symmetric(vertical: 7.v),
                            padding: EdgeInsets.symmetric(
                                horizontal: 7.h, vertical: 14.v),
                            decoration: AppDecoration.fillBlueGray,
                            child: Column(children: [
                              SizedBox(height: 3.v),
                              AppbarImage2(
                                  svgPath: ImageConstant.imgArrow2,
                                  onTap: () {
                                    onTapArrowtwoone(context);
                                  })
                            ])),
                        AppbarTitle(
                            text: "Favourites",
                            margin: EdgeInsets.only(left: 46.h, bottom: 3.v)),
                        AppbarImage3(
                            svgPath: ImageConstant.imgSearch,
                            margin: EdgeInsets.only(left: 49.h, top: 7.v))
                      ])),
                  SizedBox(height: 12.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child:
                          SizedBox(width: double.maxFinite, child: Divider()))
                ]),
                styleType: Style.bgFill),
            body: SizedBox(
                width: mediaQueryData.size.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 16.v),
                    child: Container(
                        height: 198.v,
                        width: 346.h,
                        margin: EdgeInsets.only(
                            left: 23.h, right: 23.h, bottom: 5.v),
                        child: Stack(alignment: Alignment.topLeft, children: [
                          Align(
                              alignment: Alignment.topCenter,
                              child: Container(
                                  margin: EdgeInsets.only(top: 1.v),
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 20.h, vertical: 9.v),
                                  decoration: AppDecoration.fillOnPrimary,
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                            width: 148.h,
                                            child: Text(
                                                "Royal Printed  Blender, Powerful 275 W Motor ,\n1 Years Warranty, Variable Speed Control, ISI- Marked, \nColors : Orange, Blue, ",
                                                maxLines: 6,
                                                overflow: TextOverflow.ellipsis,
                                                style: theme
                                                    .textTheme.labelLarge)),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                top: 7.v,
                                                right: 24.h,
                                                bottom: 2.v),
                                            child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                children: [
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          top: 2.v),
                                                      child: Column(children: [
                                                        Text("Rs.3,150",
                                                            style: CustomTextStyles
                                                                .titleLargeInter),
                                                        SizedBox(height: 4.v),
                                                        Text("Free delivery",
                                                            style:
                                                                CustomTextStyles
                                                                    .labelLarge12)
                                                      ])),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          left: 12.h,
                                                          bottom: 4.v),
                                                      child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            CustomImageView(
                                                                svgPath:
                                                                    ImageConstant
                                                                        .imgSearchPrimary,
                                                                height: 30
                                                                    .adaptSize,
                                                                width: 30
                                                                    .adaptSize),
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left:
                                                                            5.h,
                                                                        top: 2
                                                                            .v),
                                                                child: Text(
                                                                    "Bag",
                                                                    style: CustomTextStyles
                                                                        .bodySmallPrimary))
                                                          ]))
                                                ]))
                                      ]))),
                          CustomImageView(
                              imagePath: ImageConstant.imgRectangle10,
                              height: 177.v,
                              width: 165.h,
                              alignment: Alignment.topLeft),
                          CustomIconButton(
                              height: 36.adaptSize,
                              width: 36.adaptSize,
                              padding: EdgeInsets.all(6.h),
                              alignment: Alignment.bottomRight,
                              child: CustomImageView(
                                  svgPath: ImageConstant.imgIconRed700))
                        ]))))));
  }

  /// Navigates to the blenderScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the blenderScreen.
  onTapArrowtwoone(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.blenderScreen);
  }
}
