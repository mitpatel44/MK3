import 'package:axit_s_application1/core/app_export.dart';
import 'package:axit_s_application1/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class MyProfilePage extends StatelessWidget {
  const MyProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                decoration: AppDecoration.outlineBlack900,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  SizedBox(height: 40.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Padding(
                              padding: EdgeInsets.only(bottom: 5.v),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomImageView(
                                        svgPath:
                                            ImageConstant.imgSearchPrimary30x30,
                                        height: 30.adaptSize,
                                        width: 30.adaptSize,
                                        alignment: Alignment.centerRight,
                                        margin: EdgeInsets.only(right: 34.h)),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            left: 32.h, top: 13.v),
                                        child: Text("My Profile",
                                            style: CustomTextStyles
                                                .headlineLargeInterBlack900)),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            left: 21.h, top: 14.v),
                                        child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              CustomImageView(
                                                  imagePath:
                                                      ImageConstant.imgImage26,
                                                  height: 62.v,
                                                  width: 63.h),
                                              Padding(
                                                  padding: EdgeInsets.only(
                                                      left: 10.h, bottom: 11.v),
                                                  child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text("Axit Patel",
                                                            style: theme
                                                                .textTheme
                                                                .titleLarge),
                                                        Text("axit@gmail.com",
                                                            style: theme
                                                                .textTheme
                                                                .bodyLarge)
                                                      ]))
                                            ])),
                                    SizedBox(height: 36.v),
                                    GestureDetector(
                                        onTap: () {
                                          onTapRowmyorders(context);
                                        },
                                        child: Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 19.h,
                                                vertical: 15.v),
                                            decoration:
                                                AppDecoration.fillOnPrimary,
                                            child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          top: 5.v),
                                                      child: Text("My Orders",
                                                          style: theme.textTheme
                                                              .titleLarge)),
                                                  CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgArrowright,
                                                      height: 24.v,
                                                      width: 17.h,
                                                      margin: EdgeInsets.only(
                                                          top: 4.v,
                                                          right: 5.h,
                                                          bottom: 5.v))
                                                ]))),
                                    SizedBox(height: 30.v),
                                    GestureDetector(
                                        onTap: () {
                                          onTapRowmanageshippi(context);
                                        },
                                        child: Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 20.h,
                                                vertical: 13.v),
                                            decoration:
                                                AppDecoration.fillOnPrimary,
                                            child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          top: 9.v),
                                                      child: Text(
                                                          "Manage Shipping addresses",
                                                          style: theme.textTheme
                                                              .titleLarge)),
                                                  CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgArrowright,
                                                      height: 24.v,
                                                      width: 17.h,
                                                      margin: EdgeInsets.only(
                                                          left: 57.h,
                                                          top: 7.v,
                                                          bottom: 8.v))
                                                ]))),
                                    SizedBox(height: 38.v),
                                    Container(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 21.h, vertical: 17.v),
                                        decoration: AppDecoration.fillOnPrimary,
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                  padding:
                                                      EdgeInsets.only(top: 1.v),
                                                  child: Text("Favorites list",
                                                      style: theme.textTheme
                                                          .titleLarge)),
                                              CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgArrowright,
                                                  height: 24.v,
                                                  width: 17.h,
                                                  margin: EdgeInsets.only(
                                                      top: 1.v, bottom: 3.v))
                                            ])),
                                    CustomElevatedButton(
                                        height: 57.v,
                                        text: "Log Out",
                                        margin: EdgeInsets.only(
                                            left: 21.h, top: 45.v, right: 24.h),
                                        onTap: () {
                                          onTapLogout(context);
                                        },
                                        alignment: Alignment.center)
                                  ]))))
                ]))));
  }

  /// Navigates to the myOrdersScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the myOrdersScreen.
  onTapRowmyorders(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.myOrdersScreen);
  }

  /// Navigates to the addressScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the addressScreen.
  onTapRowmanageshippi(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.addressScreen);
  }

  /// Navigates to the welcomeScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the welcomeScreen.
  onTapLogout(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.welcomeScreen);
  }
}
