// ignore_for_file: must_be_immutable

import 'package:axit_s_application1/core/app_export.dart';
import 'package:axit_s_application1/presentation/categories_page/categories_page.dart';
import 'package:axit_s_application1/presentation/favorites_page/favorites_page.dart';
import 'package:axit_s_application1/presentation/home_page/home_page.dart';
import 'package:axit_s_application1/presentation/my_bag_page/my_bag_page.dart';
import 'package:axit_s_application1/presentation/my_profile_page/my_profile_page.dart';
import 'package:axit_s_application1/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

class ConfirmOrdersScreen extends StatelessWidget {
  ConfirmOrdersScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 89.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 5.v),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgEllipse5,
                          height: 236.adaptSize,
                          width: 236.adaptSize,
                          radius: BorderRadius.circular(
                            118.h,
                          ),
                          margin: EdgeInsets.only(left: 64.h),
                        ),
                        SizedBox(height: 11.v),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            "Your Order is Confirm.",
                            style:
                                CustomTextStyles.headlineLargeInterBluegray800,
                          ),
                        ),
                        SizedBox(height: 44.v),
                        CustomImageView(
                          imagePath: ImageConstant.imgImage22,
                          height: 278.v,
                          width: 393.h,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomBar(
          onChanged: (BottomBarEnum type) {
            Navigator.pushNamed(
                navigatorKey.currentContext!, getCurrentRoute(type));
          },
        ),
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homePage;
      case BottomBarEnum.Shop:
        return AppRoutes.categoriesPage;
      case BottomBarEnum.Bag:
        return AppRoutes.myBagPage;
      case BottomBarEnum.Favorites:
        return AppRoutes.favoritesPage;
      case BottomBarEnum.Profile:
        return AppRoutes.myProfilePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage();
      case AppRoutes.categoriesPage:
        return CategoriesPage();
      case AppRoutes.myBagPage:
        return MyBagPage();
      case AppRoutes.favoritesPage:
        return FavoritesPage();
      case AppRoutes.myProfilePage:
        return MyProfilePage();
      default:
        return DefaultWidget();
    }
  }
}
