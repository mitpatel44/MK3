import 'package:axit_s_application1/core/app_export.dart';
import 'package:axit_s_application1/presentation/categories_page/categories_page.dart';
import 'package:axit_s_application1/presentation/favorites_page/favorites_page.dart';
import 'package:axit_s_application1/presentation/home_page/home_page.dart';
import 'package:axit_s_application1/presentation/my_bag_page/my_bag_page.dart';
import 'package:axit_s_application1/presentation/my_profile_page/my_profile_page.dart';
import 'package:axit_s_application1/widgets/app_bar/appbar_image_2.dart';
import 'package:axit_s_application1/widgets/app_bar/appbar_subtitle.dart';
import 'package:axit_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:axit_s_application1/widgets/custom_bottom_bar.dart';
import 'package:axit_s_application1/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class AddressScreen extends StatelessWidget {
  AddressScreen({Key? key}) : super(key: key);

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            appBar: CustomAppBar(
                height: 80.v,
                centerTitle: true,
                title: Column(children: [
                  Padding(
                      padding: EdgeInsets.only(left: 22.h, right: 50.h),
                      child: Row(children: [
                        GestureDetector(
                            onTap: () {
                              onTapStackarrowtwo(context);
                            },
                            child: Container(
                                margin: EdgeInsets.only(bottom: 2.v),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 7.h, vertical: 14.v),
                                decoration: AppDecoration.fillBlueGray,
                                child: Column(children: [
                                  SizedBox(height: 3.v),
                                  AppbarImage2(svgPath: ImageConstant.imgArrow2)
                                ]))),
                        AppbarSubtitle(
                            text: "Add Shipping Address",
                            margin: EdgeInsets.only(left: 18.h))
                      ])),
                  SizedBox(height: 16.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child:
                          SizedBox(width: double.maxFinite, child: Divider()))
                ]),
                styleType: Style.bgFill_1),
            body: SizedBox(
                width: double.maxFinite,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  SizedBox(height: 33.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Padding(
                              padding: EdgeInsets.only(
                                  left: 18.h, right: 25.h, bottom: 5.v),
                              child: Column(children: [
                                Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 30.h, vertical: 9.v),
                                    decoration: AppDecoration.outlineBlack9003
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder10),
                                    child: Text("First Name",
                                        style: theme.textTheme.titleLarge)),
                                SizedBox(height: 19.v),
                                Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 30.h, vertical: 9.v),
                                    decoration: AppDecoration.outlineBlack9003
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder10),
                                    child: Text("Last Name",
                                        style: theme.textTheme.titleLarge)),
                                CustomElevatedButton(
                                    height: 53.v,
                                    text: "Address",
                                    margin:
                                        EdgeInsets.only(top: 19.v, right: 6.h),
                                    buttonStyle:
                                        CustomButtonStyles.outlineBlack,
                                    buttonTextStyle:
                                        theme.textTheme.titleLarge!),
                                SizedBox(height: 19.v),
                                Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 30.h, vertical: 11.v),
                                    decoration: AppDecoration.outlineBlack9003
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder10),
                                    child: Text("City",
                                        style: theme.textTheme.titleLarge)),
                                SizedBox(height: 19.v),
                                Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 30.h, vertical: 9.v),
                                    decoration: AppDecoration.outlineBlack9003
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder10),
                                    child: Text("State",
                                        style: theme.textTheme.titleLarge)),
                                SizedBox(height: 19.v),
                                Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 30.h, vertical: 11.v),
                                    decoration: AppDecoration.outlineBlack9003
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder10),
                                    child: Text("Country",
                                        style: theme.textTheme.titleLarge)),
                                CustomElevatedButton(
                                    height: 48.v,
                                    text: "SAVE ADDRESS",
                                    margin:
                                        EdgeInsets.only(left: 7.h, top: 36.v),
                                    buttonStyle: CustomButtonStyles
                                        .outlineErrorContainer,
                                    buttonTextStyle:
                                        theme.textTheme.titleSmall!,
                                    onTap: () {
                                      onTapSaveaddress(context);
                                    })
                              ]))))
                ])),
            bottomNavigationBar:
                CustomBottomBar(onChanged: (BottomBarEnum type) {
              Navigator.pushNamed(
                  navigatorKey.currentContext!, getCurrentRoute(type));
            })));
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homePage;
      case BottomBarEnum.Shop:
        return AppRoutes.categoriesPage;
      case BottomBarEnum.Bag:
        return AppRoutes.myBagPage;
      case BottomBarEnum.Favorites:
        return AppRoutes.favoritesPage;
      case BottomBarEnum.Profile:
        return AppRoutes.myProfilePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homePage:
        return HomePage();
      case AppRoutes.categoriesPage:
        return CategoriesPage();
      case AppRoutes.myBagPage:
        return MyBagPage();
      case AppRoutes.favoritesPage:
        return FavoritesPage();
      case AppRoutes.myProfilePage:
        return MyProfilePage();
      default:
        return DefaultWidget();
    }
  }

  /// Navigates to the checkoutScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the checkoutScreen.
  onTapStackarrowtwo(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.checkoutScreen);
  }

  /// Navigates to the checkoutScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the checkoutScreen.
  onTapSaveaddress(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.checkoutScreen);
  }
}
