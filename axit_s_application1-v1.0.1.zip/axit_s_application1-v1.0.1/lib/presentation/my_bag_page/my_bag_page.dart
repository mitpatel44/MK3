import 'package:axit_s_application1/core/app_export.dart';
import 'package:axit_s_application1/widgets/app_bar/appbar_image_2.dart';
import 'package:axit_s_application1/widgets/app_bar/appbar_image_3.dart';
import 'package:axit_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:axit_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:axit_s_application1/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class MyBagPage extends StatelessWidget {
  const MyBagPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            appBar: CustomAppBar(
                height: 79.v,
                centerTitle: true,
                title: Column(children: [
                  Padding(
                      padding: EdgeInsets.only(left: 22.h, right: 30.h),
                      child: Row(children: [
                        GestureDetector(
                            onTap: () {
                              onTapStackarrowtwo(context);
                            },
                            child: Container(
                                margin: EdgeInsets.only(top: 4.v, bottom: 10.v),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 7.h, vertical: 14.v),
                                decoration: AppDecoration.fillBlueGray,
                                child: Column(children: [
                                  SizedBox(height: 3.v),
                                  AppbarImage2(svgPath: ImageConstant.imgArrow2)
                                ]))),
                        AppbarTitle(
                            text: "My Bag",
                            margin: EdgeInsets.only(left: 75.h, bottom: 3.v)),
                        AppbarImage3(
                            svgPath: ImageConstant.imgSearch,
                            margin: EdgeInsets.only(left: 79.h, top: 7.v))
                      ])),
                  SizedBox(height: 8.v),
                  SizedBox(width: double.maxFinite, child: Divider())
                ]),
                styleType: Style.bgFill),
            body: SizedBox(
                width: mediaQueryData.size.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 17.v),
                    child: Container(
                        height: 257.v,
                        width: 346.h,
                        margin: EdgeInsets.only(
                            left: 22.h, right: 25.h, bottom: 5.v),
                        child: Stack(alignment: Alignment.center, children: [
                          Align(
                              alignment: Alignment.topCenter,
                              child: Container(
                                  height: 177.v,
                                  width: 346.h,
                                  decoration: BoxDecoration(
                                      color: theme.colorScheme.onPrimary))),
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 2.h, vertical: 1.v),
                                  decoration: AppDecoration.fillOnPrimary,
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Padding(
                                            padding:
                                                EdgeInsets.only(right: 9.h),
                                            child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgImage18,
                                                      height: 176.v,
                                                      width: 165.h),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          left: 8.h,
                                                          top: 8.v,
                                                          bottom: 25.v),
                                                      child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            SizedBox(
                                                                height: 98.v,
                                                                width: 160.h,
                                                                child: Stack(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    children: [
                                                                      Align(
                                                                          alignment: Alignment
                                                                              .center,
                                                                          child: SizedBox(
                                                                              width: 160.h,
                                                                              child: Text("Portable Hand Blender, Powerful 275 W Motor ,\n5 Years Warranty* First in India | Variable Speed Control | ISI- Marked, \nColors : Yellow, Blue, Pink", maxLines: 6, overflow: TextOverflow.ellipsis, style: theme.textTheme.labelLarge))),
                                                                      Align(
                                                                          alignment: Alignment
                                                                              .center,
                                                                          child: SizedBox(
                                                                              width: 160.h,
                                                                              child: Text("Portable Hand Blender, Powerful 275 W Motor ,\n5 Years Warranty* First in India | Variable Speed Control | ISI- Marked, \nColors : Yellow, Blue, Pink", maxLines: 6, overflow: TextOverflow.ellipsis, style: theme.textTheme.labelLarge)))
                                                                    ])),
                                                            SizedBox(
                                                                height: 4.v),
                                                            Text("Rs.2,050",
                                                                style: CustomTextStyles
                                                                    .titleLargeInter),
                                                            Text(
                                                                "Free delivery",
                                                                style: CustomTextStyles
                                                                    .labelLarge12)
                                                          ]))
                                                ])),
                                        Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                41.h, 20.v, 25.h, 17.v),
                                            child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Container(
                                                      width: 166.h,
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 13.h),
                                                      decoration: AppDecoration
                                                          .fillBlueGray
                                                          .copyWith(
                                                              borderRadius:
                                                                  BorderRadiusStyle
                                                                      .roundedBorder10),
                                                      child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            CustomImageView(
                                                                svgPath:
                                                                    ImageConstant
                                                                        .imgTrash,
                                                                height: 23.v,
                                                                width: 28.h,
                                                                margin: EdgeInsets
                                                                    .symmetric(
                                                                        vertical:
                                                                            9.v)),
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left: 14
                                                                            .h),
                                                                child: SizedBox(
                                                                    height:
                                                                        41.v,
                                                                    child: VerticalDivider(
                                                                        width:
                                                                            1.h,
                                                                        thickness:
                                                                            1.v,
                                                                        color: appTheme
                                                                            .black900))),
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left: 23
                                                                            .h,
                                                                        top:
                                                                            5.v,
                                                                        bottom: 6
                                                                            .v),
                                                                child: Text("1",
                                                                    style: CustomTextStyles
                                                                        .headlineSmallBlack900)),
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left: 27
                                                                            .h),
                                                                child: SizedBox(
                                                                    height:
                                                                        41.v,
                                                                    child: VerticalDivider(
                                                                        width:
                                                                            1.h,
                                                                        thickness:
                                                                            1.v,
                                                                        color: appTheme
                                                                            .black900))),
                                                            CustomImageView(
                                                                imagePath:
                                                                    ImageConstant
                                                                        .imgImage21,
                                                                height: 23
                                                                    .adaptSize,
                                                                width: 23
                                                                    .adaptSize,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        left: 12
                                                                            .h,
                                                                        top:
                                                                            9.v,
                                                                        bottom:
                                                                            9.v))
                                                          ])),
                                                  CustomElevatedButton(
                                                      height: 41.v,
                                                      width: 92.h,
                                                      text: "Delete",
                                                      margin: EdgeInsets.only(
                                                          left: 18.h),
                                                      buttonStyle:
                                                          CustomButtonStyles
                                                              .fillBlueGrayTL10,
                                                      buttonTextStyle:
                                                          CustomTextStyles
                                                              .titleMediumInterPrimary)
                                                ]))
                                      ])))
                        ]))))));
  }

  /// Navigates to the blenderScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the blenderScreen.
  onTapStackarrowtwo(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.blenderScreen);
  }
}
