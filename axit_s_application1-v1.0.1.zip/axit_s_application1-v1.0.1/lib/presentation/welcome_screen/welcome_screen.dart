import 'package:axit_s_application1/core/app_export.dart';
import 'package:axit_s_application1/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 9.h),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Text("Welcome",
                              style: theme.textTheme.headlineLarge)),
                      Container(
                          width: 243.h,
                          margin: EdgeInsets.only(left: 31.h, top: 4.v),
                          child: Text(
                              "Please login or sign up to continue using\nour app",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style:
                                  CustomTextStyles.labelLargeMplus1pBoldBold)),
                      SizedBox(height: 21.v),
                      CustomImageView(
                          imagePath: ImageConstant.imgWhatsappimage20230909,
                          height: 181.v,
                          width: 315.h,
                          alignment: Alignment.center),
                      Container(
                          height: 196.v,
                          width: 357.h,
                          margin: EdgeInsets.only(left: 15.h, top: 23.v),
                          child: Stack(alignment: Alignment.center, children: [
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: SizedBox(
                                    width: 341.h,
                                    child: Divider(color: appTheme.black900))),
                            Align(
                                alignment: Alignment.center,
                                child: SizedBox(
                                    height: 192.v,
                                    width: 357.h,
                                    child: Stack(
                                        alignment: Alignment.centerLeft,
                                        children: [
                                          Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                  height: 60.v,
                                                  width: 72.h,
                                                  margin: EdgeInsets.only(
                                                      top: 50.v),
                                                  child: Stack(
                                                      alignment:
                                                          Alignment.topRight,
                                                      children: [
                                                        Align(
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            child: Container(
                                                                height: 45.v,
                                                                width: 48.h,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        left: 6
                                                                            .h),
                                                                child: Stack(
                                                                    alignment:
                                                                        Alignment
                                                                            .bottomLeft,
                                                                    children: [
                                                                      CustomImageView(
                                                                          svgPath: ImageConstant
                                                                              .imgCheckmark,
                                                                          height: 45
                                                                              .v,
                                                                          width: 48
                                                                              .h,
                                                                          alignment:
                                                                              Alignment.center),
                                                                      Align(
                                                                          alignment:
                                                                              Alignment.bottomLeft,
                                                                          child: Padding(
                                                                              padding: EdgeInsets.only(left: 1.h, bottom: 3.v),
                                                                              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                                                                                CustomImageView(imagePath: ImageConstant.imgImage3, height: 13.v, width: 25.h, alignment: Alignment.centerRight),
                                                                                CustomImageView(imagePath: ImageConstant.imgImage1, height: 15.v, width: 24.h)
                                                                              ])))
                                                                    ]))),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage5,
                                                            height: 25.v,
                                                            width: 27.h,
                                                            alignment: Alignment
                                                                .topRight),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage2,
                                                            height: 24.v,
                                                            width: 18.h,
                                                            alignment: Alignment
                                                                .centerLeft),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage4,
                                                            height: 24.v,
                                                            width: 14.h,
                                                            alignment: Alignment
                                                                .topLeft,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left: 27.h))
                                                      ]))),
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: SizedBox(
                                                  height: 192.v,
                                                  width: 313.h,
                                                  child: Stack(
                                                      alignment:
                                                          Alignment.bottomRight,
                                                      children: [
                                                        CustomImageView(
                                                            svgPath:
                                                                ImageConstant
                                                                    .imgFrame4,
                                                            height: 146.v,
                                                            width: 88.h),
                                                        Align(
                                                            alignment: Alignment
                                                                .bottomRight,
                                                            child: Container(
                                                                height: 74.v,
                                                                width: 62.h,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        right: 15
                                                                            .h,
                                                                        bottom: 5
                                                                            .v),
                                                                child: Stack(
                                                                    alignment:
                                                                        Alignment
                                                                            .topRight,
                                                                    children: [
                                                                      CustomImageView(
                                                                          svgPath: ImageConstant
                                                                              .imgNotification,
                                                                          height: 56
                                                                              .v,
                                                                          width: 35
                                                                              .h,
                                                                          alignment: Alignment
                                                                              .topRight,
                                                                          margin: EdgeInsets.only(
                                                                              top: 2.v,
                                                                              right: 2.h)),
                                                                      Align(
                                                                          alignment:
                                                                              Alignment.topRight,
                                                                          child: SizedBox(
                                                                              height: 69.v,
                                                                              width: 42.h,
                                                                              child: Stack(alignment: Alignment.centerLeft, children: [
                                                                                CustomImageView(svgPath: ImageConstant.imgVector6, height: 69.v, width: 42.h, alignment: Alignment.center),
                                                                                Align(
                                                                                    alignment: Alignment.centerLeft,
                                                                                    child: Container(
                                                                                        height: 54.v,
                                                                                        width: 29.h,
                                                                                        margin: EdgeInsets.only(left: 1.h),
                                                                                        child: Stack(alignment: Alignment.center, children: [
                                                                                          Align(
                                                                                              alignment: Alignment.topRight,
                                                                                              child: Row(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                                                                                                CustomImageView(svgPath: ImageConstant.imgVector8, height: 5.v, width: 1.h, margin: EdgeInsets.only(top: 8.v, bottom: 12.v)),
                                                                                                Padding(
                                                                                                    padding: EdgeInsets.only(left: 4.h),
                                                                                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                                                                                      CustomImageView(svgPath: ImageConstant.imgVector9, height: 2.v, width: 9.h, alignment: Alignment.centerRight),
                                                                                                      SizedBox(height: 20.v),
                                                                                                      CustomImageView(svgPath: ImageConstant.imgVector10, height: 4.adaptSize, width: 4.adaptSize)
                                                                                                    ]))
                                                                                              ])),
                                                                                          CustomImageView(imagePath: ImageConstant.imgLine4, height: 54.v, width: 29.h, alignment: Alignment.center)
                                                                                        ])))
                                                                              ]))),
                                                                      CustomImageView(
                                                                          imagePath: ImageConstant
                                                                              .imgVector1,
                                                                          height: 65
                                                                              .v,
                                                                          width: 38
                                                                              .h,
                                                                          alignment:
                                                                              Alignment.bottomLeft)
                                                                    ]))),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage8,
                                                            height: 10.v,
                                                            width: 19.h),
                                                        Align(
                                                            alignment: Alignment
                                                                .topLeft,
                                                            child: Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left: 83
                                                                            .h,
                                                                        top: 45
                                                                            .v),
                                                                child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Align(
                                                                          alignment: Alignment
                                                                              .centerRight,
                                                                          child: Container(
                                                                              height: 9.adaptSize,
                                                                              width: 9.adaptSize,
                                                                              decoration: BoxDecoration(border: Border.all(color: appTheme.black900, width: 1.h)))),
                                                                      SizedBox(
                                                                          height:
                                                                              9.v),
                                                                      CustomImageView(
                                                                          svgPath: ImageConstant
                                                                              .imgFrame11,
                                                                          height: 11
                                                                              .v,
                                                                          width:
                                                                              45.h)
                                                                    ]))),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgVector2,
                                                            height: 37.v,
                                                            width: 66.h,
                                                            alignment: Alignment
                                                                .bottomRight,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    bottom:
                                                                        5.v)),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage6,
                                                            height: 56.v,
                                                            width: 57.h,
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left:
                                                                        101.h)),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage7,
                                                            height: 19.v,
                                                            width: 21.h,
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left: 106.h,
                                                                    bottom:
                                                                        38.v)),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage10,
                                                            height: 21.v,
                                                            width: 18.h,
                                                            alignment: Alignment
                                                                .centerLeft,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left:
                                                                        97.h)),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage11,
                                                            height: 21.v,
                                                            width: 17.h,
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left: 86.h,
                                                                    bottom:
                                                                        70.v)),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage11,
                                                            height: 17.v,
                                                            width: 15.h,
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left: 88.h,
                                                                    bottom:
                                                                        55.v)),
                                                        Align(
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            child: Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left: 90
                                                                            .h,
                                                                        bottom: 25
                                                                            .v),
                                                                child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    children: [
                                                                      CustomImageView(
                                                                          imagePath: ImageConstant
                                                                              .imgImage13,
                                                                          height: 25
                                                                              .v,
                                                                          width:
                                                                              26.h),
                                                                      SizedBox(
                                                                          height:
                                                                              1.v),
                                                                      Container(
                                                                          height: 2
                                                                              .adaptSize,
                                                                          width: 2
                                                                              .adaptSize,
                                                                          decoration: BoxDecoration(
                                                                              color: theme.colorScheme.primaryContainer,
                                                                              borderRadius: BorderRadius.circular(1.h)))
                                                                    ]))),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgImage9,
                                                            height: 12.v,
                                                            width: 15.h,
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left: 103.h,
                                                                    bottom:
                                                                        52.v)),
                                                        Align(
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            child: Container(
                                                                height:
                                                                    7.adaptSize,
                                                                width:
                                                                    7.adaptSize,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        left: 95
                                                                            .h,
                                                                        bottom: 18
                                                                            .v),
                                                                decoration: BoxDecoration(
                                                                    color: theme
                                                                        .colorScheme
                                                                        .onErrorContainer,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            3.h)))),
                                                        Align(
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            child: Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left: 98
                                                                            .h),
                                                                child: SizedBox(
                                                                    height:
                                                                        18.v,
                                                                    child: VerticalDivider(
                                                                        width:
                                                                            1.h,
                                                                        thickness:
                                                                            1.v,
                                                                        color: appTheme
                                                                            .black900,
                                                                        endIndent:
                                                                            3.h)))),
                                                        Align(
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            child: Container(
                                                                height: 10.v,
                                                                width: 11.h,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        left: 88
                                                                            .h,
                                                                        bottom: 7
                                                                            .v),
                                                                decoration: BoxDecoration(
                                                                    color: theme
                                                                        .colorScheme
                                                                        .onErrorContainer,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            5.h)))),
                                                        Align(
                                                            alignment: Alignment
                                                                .topLeft,
                                                            child: Container(
                                                                height: 30.v,
                                                                width: 32.h,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        left: 112
                                                                            .h),
                                                                decoration: BoxDecoration(
                                                                    color: appTheme
                                                                        .pinkA400))),
                                                        CustomImageView(
                                                            svgPath:
                                                                ImageConstant
                                                                    .imgForward,
                                                            height:
                                                                17.adaptSize,
                                                            width: 17.adaptSize,
                                                            alignment: Alignment
                                                                .topLeft,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left: 134.h,
                                                                    top: 18.v)),
                                                        Align(
                                                            alignment: Alignment
                                                                .topLeft,
                                                            child: Container(
                                                                height: 7
                                                                    .adaptSize,
                                                                width:
                                                                    7.adaptSize,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        left: 139
                                                                            .h,
                                                                        top: 7
                                                                            .v),
                                                                decoration: BoxDecoration(
                                                                    color: appTheme
                                                                        .deepPurple500))),
                                                        Align(
                                                            alignment: Alignment
                                                                .topLeft,
                                                            child: Container(
                                                                height: 8.v,
                                                                width: 9.h,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        left: 80
                                                                            .h,
                                                                        top: 25
                                                                            .v),
                                                                decoration: BoxDecoration(
                                                                    color: appTheme
                                                                        .blueGray100,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            4.h)))),
                                                        CustomImageView(
                                                            imagePath:
                                                                ImageConstant
                                                                    .imgWoman,
                                                            height: 170.v,
                                                            width: 82.h,
                                                            alignment: Alignment
                                                                .bottomLeft,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    bottom:
                                                                        3.v))
                                                      ]))),
                                          Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                  height: 9.adaptSize,
                                                  width: 9.adaptSize,
                                                  margin: EdgeInsets.only(
                                                      top: 30.v, right: 27.h),
                                                  decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color:
                                                              appTheme.black900,
                                                          width: 1.h))))
                                        ])))
                          ])),
                      Padding(
                          padding: EdgeInsets.only(
                              top: 46.v, right: 5.h, bottom: 3.v),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                    child: CustomElevatedButton(
                                        text: "Sign in",
                                        margin: EdgeInsets.only(right: 4.h),
                                        onTap: () {
                                          onTapSignin(context);
                                        })),
                                Expanded(
                                    child: CustomElevatedButton(
                                        text: "Sign up",
                                        margin: EdgeInsets.only(left: 4.h),
                                        onTap: () {
                                          onTapSignup(context);
                                        }))
                              ]))
                    ]))));
  }

  /// Navigates to the loginScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the loginScreen.
  onTapSignin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginScreen);
  }

  /// Navigates to the signUpScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [Navigator] widget
  /// to push the named route for the signUpScreen.
  onTapSignup(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signUpScreen);
  }
}
